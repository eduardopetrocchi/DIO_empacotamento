# Correção de Endereços

Um módulo Python simples para corrigir endereços substituindo '\\' por '/'.

## Instalação

```bash
pip install correcao_enderecos
```

## Uso

```python
from correcao_endereco import substituicao

endereco = "C:\\Users\\MeuUsuario\\Desktop"
endereco_corrigido = substituicao(endereco)
print(f"Original: {endereco}")
print(f"Corrigido: {endereco_corrigido}")
```

## Contribuição

1. Fork do repositório.
2. Crie uma branch: `git checkout -b feature/nova-funcionalidade`.
3. Faça as alterações e commit.
4. Push para a branch: `git push origin feature/nova-funcionalidade`.
5. Abra um Pull Request.

## Licença

Distribuído sob a licença [MIT](LICENSE).
```

Agora, os usuários podem instalar o seu módulo diretamente do PyPI usando o comando `pip install correcao-enderecos`. Certifique-se de ter registrado o seu projeto no PyPI e que o nome `correcao-enderecos` seja o mesmo utilizado para a distribuição no PyPI.
## Autores

- [@eduardopetrocchi](https://www.github.com/eduardopetrocchi)

